import urllib
print "OK"
exit()
